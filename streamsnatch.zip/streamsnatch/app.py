# from flask import Flask, request, render_template, send_from_directory, url_for
# import yt_dlp
# import os

# app = Flask(__name__)
# DOWNLOAD_DIR = "downloads"
# os.makedirs(DOWNLOAD_DIR, exist_ok=True)

# @app.route("/", methods=["GET", "POST"])
# def index():
#     status = ""
#     file_url = ""
#     thumbnail = ""

#     if request.method == "POST":
#         url = request.form.get("url")
#         if url:
#             try:
#                 ydl_opts = {
#                     'format': 'bestvideo+bestaudio/best',
#                     'outtmpl': os.path.join(DOWNLOAD_DIR, '%(title)s.%(ext)s'),
#                     'merge_output_format': 'mp4',
#                     'noplaylist': True,
#                     'nocheckcertificate': True,
#                     'cachedir': False
#                 }

#                 with yt_dlp.YoutubeDL(ydl_opts) as ydl:
#                     info = ydl.extract_info(url, download=True)
#                     filename = ydl.prepare_filename(info)
#                     title = info.get("title", "No Title")
#                     thumbnail = info.get("thumbnail", "")
#                     status = f"✅ '{title}' downloaded successfully!"
#                     file_url = os.path.basename(filename)

#             except Exception as e:
#                 status = f"❌ Error: {str(e)}"

#     return render_template("index.html", status=status, file_url=file_url, thumbnail=thumbnail)

# @app.route("/download/<path:filename>")
# def download(filename):
#     return send_from_directory(DOWNLOAD_DIR, filename, as_attachment=True)

# if __name__ == "__main__":
#     app.run(debug=True, port=5000)
from flask import Flask, request, render_template, send_from_directory, url_for
import yt_dlp
import os

app = Flask(__name__)

# Define download directory
DOWNLOAD_DIR = "downloads"
os.makedirs(DOWNLOAD_DIR, exist_ok=True)

@app.route("/", methods=["GET", "POST"])
def index():
    status = ""
    file_url = ""
    thumbnail = ""

    if request.method == "POST":
        url = request.form.get("url")
        if url:
            try:
                ydl_opts = {
                    'format': 'bestvideo+bestaudio/best',
                    'outtmpl': os.path.join(DOWNLOAD_DIR, '%(title)s.%(ext)s'),
                    'merge_output_format': 'mp4',
                    'noplaylist': True,
                    'nocheckcertificate': True,
                    'cachedir': False
                }

                with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                    info = ydl.extract_info(url, download=True)
                    filename = ydl.prepare_filename(info)
                    title = info.get("title", "No Title")

                    # Get thumbnail
                    thumbnail = info.get("thumbnail")
                    if not thumbnail and "thumbnails" in info:
                        thumbnail = info["thumbnails"][-1]["url"]
                    if not thumbnail:
                        thumbnail = url_for('static', filename='default-thumbnail.png')

                    status = f"✅ '{title}' downloaded successfully!"
                    file_url = os.path.basename(filename)

            except Exception as e:
                status = f"❌ Error: {str(e)}"
                thumbnail = url_for('static', filename='default-thumbnail.png')

    return render_template("index.html", status=status, file_url=file_url, thumbnail=thumbnail)

@app.route("/download/<path:filename>")
def download(filename):
    return send_from_directory(DOWNLOAD_DIR, filename, as_attachment=True)

if __name__ == "__main__":
    app.run(debug=True, port=5000)
